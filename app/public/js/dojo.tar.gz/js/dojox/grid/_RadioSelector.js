//>>built
define("dojox/grid/_RadioSelector",["../main","./_Selector"],function(_1){
return _1.grid._RadioSelector;
});
