//>>built
define("dojox/grid/nls/DataGrid_de",{"dijit/nls/loading":{"loadingState":"Wird geladen...","errorState":"Es ist ein Fehler aufgetreten."}});
