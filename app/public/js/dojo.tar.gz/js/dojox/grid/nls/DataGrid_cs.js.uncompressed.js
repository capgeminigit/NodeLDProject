define('dojox/grid/nls/DataGrid_cs',{
'dijit/nls/loading':{"loadingState":"Probíhá načítání...","errorState":"Omlouváme se, došlo k chybě"}
});