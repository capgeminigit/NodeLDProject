//>>built
define("dojox/grid/nls/DataGrid_nb",{"dijit/nls/loading":{"loadingState":"Laster inn...","errorState":"Det oppsto en feil"}});
