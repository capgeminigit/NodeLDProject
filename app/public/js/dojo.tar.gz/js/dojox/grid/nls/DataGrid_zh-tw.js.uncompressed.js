define('dojox/grid/nls/DataGrid_zh-tw',{
'dijit/nls/loading':{"loadingState":"載入中...","errorState":"抱歉，發生錯誤"}
});