//>>built
define("dojox/grid/_CheckBoxSelector",["../main","./_Selector"],function(_1){
return _1.grid._CheckBoxSelector;
});
