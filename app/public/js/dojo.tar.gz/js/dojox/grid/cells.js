//>>built
define("dojox/grid/cells",["../main","./cells/_base"],function(_1){
return _1.grid.cells;
});
