define(
"dojox/grid/enhanced/nls/de/EnhancedGrid", ({
	singleSort: "Einfache Sortierung",
	nestedSort: "Verschachtelte Sortierung",
	ascending: "Für aufsteigende Sortierung hier klicken",
	descending: "Für absteigende Sortierung hier klicken",
	sortingState: "${0} - ${1}",
	unsorted: "Diese Spalte nicht sortieren",
	indirectSelectionRadio: "Zeile ${0}, Einzelauswahl, Optionsfeld",
	indirectSelectionCheckBox: "Zeile ${0}, Mehrfachauswahl, Kontrollkästchen",
	selectAll: "Alles auswählen"
})
);
