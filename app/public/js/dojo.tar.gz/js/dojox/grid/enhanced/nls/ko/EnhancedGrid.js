//>>built
define("dojox/grid/enhanced/nls/ko/EnhancedGrid",({singleSort:"단일 정렬",nestedSort:"중첩된 정렬",ascending:"오름차순으로 정렬하려면 클릭",descending:"내림차순으로 정렬하려면 클릭",sortingState:"${0} - ${1}",unsorted:"이 컬럼을 정렬하지 않음",indirectSelectionRadio:"행 ${0}, 단일 선택, 단일 선택 단추",indirectSelectionCheckBox:"행 ${0}, 다중 선택, 선택란",selectAll:"모두 선택"}));
