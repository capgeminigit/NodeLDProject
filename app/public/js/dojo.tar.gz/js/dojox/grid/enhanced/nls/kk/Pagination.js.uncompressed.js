define(
"dojox/grid/enhanced/nls/kk/Pagination", ({
	"descTemplate": "${1} ${0} элементтің ${2} - ${3} элементі",
	"firstTip": "Бірінші бет",
	"lastTip": "Соңғы бет",
	"nextTip": "Келесі бет",
	"prevTip": "Алдыңғы бет",
	"itemTitle": "элементтер",
	"singularItemTitle": "элемент",
	"pageStepLabelTemplate": "Бет ${0}",
	"pageSizeLabelTemplate": "Бетіне ${0} элемент",
	"allItemsLabelTemplate": "Барлық элементтер",
	"gotoButtonTitle": "Белгілі бір бетке өту",
	"dialogTitle": "Бетке өту",
	"dialogIndication": "Бет нөмірін көрсету",
	"pageCountIndication": " (${0} бет)",
	"dialogConfirm": "Өту",
	"dialogCancel": "Болдырмау",
	"all": "Барлығы"
})
);
