define(
"dojox/grid/enhanced/nls/ja/Pagination", ({
	"descTemplate": "${2} - ${3}/${1} ${0}",
	"firstTip": "最初のページ",
	"lastTip": "最後のページ",
	"nextTip": "次のページ",
	"prevTip": "前のページ",
	"itemTitle": "項目",
	"singularItemTitle": "項目",
	"pageStepLabelTemplate": "ページ ${0}",
	"pageSizeLabelTemplate": "ページ当たり ${0} 項目",
	"allItemsLabelTemplate": "すべての項目",
	"gotoButtonTitle": "特定のページに移動",
	"dialogTitle": "ページに移動",
	"dialogIndication": "ページ番号の指定",
	"pageCountIndication": " (${0} ページ)",
	"dialogConfirm": "移動",
	"dialogCancel": "キャンセル",
	"all": "すべて"
})
);
