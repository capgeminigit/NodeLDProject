define(
"dojox/grid/enhanced/nls/nl/EnhancedGrid", ({
	singleSort: "Enkelvoudig sorteren",
	nestedSort: "Genest sorteren",
	ascending: "Klik hier voor oplopend sorteren",
	descending: "Klik hier voor aflopend sorteren",
	sortingState: "${0} - ${1}",
	unsorted: "Deze kolom niet sorteren",
	indirectSelectionRadio: "Rij ${0}, enkele selectie, keuzerondje",
	indirectSelectionCheckBox: "Rij ${0}, meerdere selecties, selectievakje",
	selectAll: "Alles selecteren"
})
);
