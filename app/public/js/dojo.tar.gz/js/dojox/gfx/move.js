//>>built
define("dojox/gfx/move",["dojo/_base/lang","./Mover","./Moveable"],function(_1){
return _1.getObject("dojox.gfx.move",true);
});
