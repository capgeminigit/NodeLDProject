define("dojox/gfx/attach", ["dojox/gfx"], function(){
	// TODO: the current implementation is not functional, please implement correctly
	/*
	dojo.getObject("dojox.gfx.arc", true);
	var r = dojox.gfx.svg.attach[dojox.gfx.renderer];
	dojo.gfx.attachSurface = r.attachSurface;
	dojo.gfx.attachNode = r.attachNode;
	return r;
	*/
});
