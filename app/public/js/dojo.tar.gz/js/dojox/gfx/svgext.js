//>>built
define("dojox/gfx/svgext",["./_base","./svg"],function(g,_1){
var _2=g.svgext={};
_1.Shape.extend({addRenderingOption:function(_3,_4){
this.rawNode.setAttribute(_3,_4);
return this;
}});
return _2;
});
