//>>built
define("dojox/gfx/canvas_attach",["dojo/_base/lang","dojo/_base/kernel","dojox/gfx/canvas"],function(_1,_2,_3){
_1.getObject("dojox.gfx.canvas_attach",true);
_2.experimental("dojox.gfx.canvas_attach");
_3.attachSurface=_3.attachNode=function(){
return null;
};
return _3;
});
