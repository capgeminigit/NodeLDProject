//>>built
define("dojox/gfx/attach",["dojox/gfx"],function(){
});
