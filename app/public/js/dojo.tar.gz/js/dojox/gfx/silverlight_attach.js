//>>built
define("dojox/gfx/silverlight_attach",["dojo/_base/kernel","dojo/_base/lang","./_base","./silverlight"],function(_1,_2,g,sl){
_2.getObject("dojox.gfx.silverlight_attach",true);
_1.experimental("dojox.gfx.silverlight_attach");
sl.attachNode=function(_3){
return null;
};
sl.attachSurface=function(_4){
return null;
};
return sl;
});
