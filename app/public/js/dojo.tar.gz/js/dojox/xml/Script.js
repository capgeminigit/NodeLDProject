//>>built
define("dojox/xml/Script",["dojo/_base/kernel","dojo/_base/declare","dojo/parser","./widgetParser"],function(_1,_2,_3){
dojo.getObject("xml",true,dojox);
_1("dojox.xml.Script",null,{constructor:function(_4,_5){
_2.instantiate(_3._processScript(_5));
}});
return dojox.xml.Script;
});
