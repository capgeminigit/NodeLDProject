//>>built
define("dojox/dgauges/IndicatorBase",["dojo/_base/declare","dojox/widget/_Invalidating"],function(_1,_2){
return _1("dojox.dgauges.IndicatorBase",_2,{value:null});
});
